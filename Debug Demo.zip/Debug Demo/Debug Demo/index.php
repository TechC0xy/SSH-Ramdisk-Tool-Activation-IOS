<html>
<title>Main menu</title>
<body>
	<a href="/deviceservices/tools/">Tools</a><br/>
	<a href="/deviceservices/deviceActivation">iDevice activation</a><br/>
	<a href="/deviceservices/checkUnbrickHealth">iDevice check unbrick health</a><br/>
	<a href="/deviceservices/showSettings">iDevice show settings</a><br/>
</body>
</html>