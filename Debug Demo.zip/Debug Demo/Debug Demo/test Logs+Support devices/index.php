<html>
<title>Tools</title>
<body>
	<a href="check-sign.php">Check signature</a><br/>
	<a href="base64-tool.php">Base64 encoding/decoding</a><br/>
	<a href="fake-request.php">Fake request</a><br/>
	<a href="process-requests.php">Processing requests files</a><br/>
	<a href="rename-requests.php">Rename requests files</a><br/>
</body>
</html>