<?php
header("Location: /deviceservices/");
?>